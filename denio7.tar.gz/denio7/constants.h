// File:    constants.h
// Author:  Joshua DeNio
// Program: 7
// Date:   5/6/2019 

// Description: This file contains constant declarations for program 7.

// set constants.
#ifndef _CONSTANTS_H
#define _CONSTANTS_H
const int TABLE_SIZE = 13;
#endif
